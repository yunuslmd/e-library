<html>
<head>
<title>About Us</title>
<style>
body{
  background: url("2.jpg");
}
.box{
  width:74%;
  height:160px;
  background-image: url("lib.jpeg");
  background-size: cover;
  margin-left: 13%;
  opacity: .9;
 border:solid 1px #CF0403;
  border-radius: 12px;

}
.boxtwo{
  background-image: url("lg3.jpg");
  background-size: cover;
  box-shadow:0px 0px 15px lightgreen;
  border-radius:12px;

}
ul{
  padding: 0  ;
  list-style: none;
}
ul li{
  float: left;
  width: 248px;
  height: 40px;
  background-color: purple;
  opacity: .8;
  line-height: 40px;
  text-align: center;
  font-size: 20px;
  margin-right: 2px;
}
ul li a{
  text-decoration: none;
  color: white;
  display: block;
}
ul li a:hover{
  background-color: green;
}
ul li ul li{
  display: none;
}
ul li:hover ul li{
  display: block;

}
.nav{
  padding-left:13%;

}
.three{
  margin-left: 60%;
  margin-top: 5px;
  box-shadow:0px 0px 15px green;
}
    td{
        text-align: center;
    }

</style>


</head>
<body>

  
    <div class="box">
     <table  style =" font-size:16pt"  align="center" width="100%" height="100%">
        <tr>
          <td style="color:white"><h1 align="center"><marquee><i>Welcome To online Library System</i>  </marquee></h1></td>
        </tr>
        <tr>
          <td align="center"><b><i><mark style="color:white;background-color:maroon";>ABOUT US</mark></i></b></td>
        </tr>
      </table>
    </div>



      <div class="nav">
        <ul>
          <li><a href="sdb.php">HOME</a></li>
          <li><a href="sbooks.php">YOUR ORDER INFO</a></li>
          <li><a style="background-color: green" href="aboutus.php">ABOUT US</a>
          </li>
          <li><a href="index.php">LOGOUT</a></li>
        </ul>
    <br><br>
    </div>
          
          
  <div class="boxtwo" style="border:solid 1px #CF0403;border-radius: 10px; width:84%; height:850px; margin-left:10%;margin-top:10px;background-color:white">
      
      <h1 style="color:yellow;text-align:center;background:rgba(255, 255, 255, 0.24)">ABOUT OUR ONLINE LIBRARY MANAGEMENT SYSTEM PROJECT </h1>
      <P style="color:white;text-align:center;width:60%;font-weight:bold;margin-left
:20%;background:rgba(0, 0, 0, 0.5);box-shadow:0px 0px 20px white;border-radius:10px;padding:3%;font-size:15px">This project is the prototype of a Simple Library Management System. Librarian has a provision to add book details like ID number, book title, author name, through the web page. In addition to this, librarian or any user has a provision to search for the available books in the library by the book id or book Name. If book details are present in the database, the search details are displayed on the web page.Student can request the librarian  for getting the book via this web.Student can easily download this book's E-Book which is PDF file.</P>
      
       <h2 style="color:#1602b2;text-align:center;background:rgba(255, 255, 255, 0.82);"> ACKNOWLEDGEMENT </h2>
      <P style="color:white;text-align:center;width:60%;font-weight:bold;margin-left
                :20%;background:rgba(0, 0, 0, 0.5);box-shadow:0px 0px 20px red;border-radius:10px;padding:3%;font-size:15px">We would like to express our special thanks of gratitude to our teacher <i>Mr.Suvashis sir</i> who gave us the goldenopportunity to do this wonderful project on the topic : ONLINE LIBRARY MANAGEMENT SYSTEM using  PHP, which also helped us indoing a lot of Research and we came to know about so many new things we are really thankful to him.
</P>
       <h2 style="color:#000000;text-align:center;background:rgba(255, 255, 255, 0.82)"> Group Members </h2>
      <div style="color:white;text-align:center;width:30%;font-weight:bold;margin-left
:30%;background:rgba(0, 0, 0, 0.5);box-shadow:0px 0px 20px #fc7af7;border-radius:10px;padding:3%;font-size:15px;height:200px;"><marquee direction="up" scrolldelay="200" >
          
         <tr><td><br/></td><td>1. ROHAN KUMAR SAH  </td><td><br/></td><td> Role = ( UI  Developer + Backend Developer )
         <br>Mail-ID : rohansah764@gmail.com</td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
         <tr><td><br/></td><td>2. ZEBA WASIMA</td><td><br/></td><td>Role  = ( UI  Developer  )<br>Mail-ID : cutekittywasima8@gmail.com</td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
           <tr><td><br/></td><td>3. LOPAMUDRA ROY </td><td><br/></td><td>Role = ( UI  Developer  + Backend Developer )<br>Mail-ID : lopamudraroy1997@gmail.com </td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
           <tr><td><br/></td><td>4. BIBHAS GAYEN </td><td><br/></td><td>Role = (UI  Developer )<br>Mail-ID :  bibhasgayen1998@gmail.com</td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
           <tr><td><br/></td><td>5. KUMARI SUNITA HANSDA</td><td><br/></td><td>Role  = ( UI  Developer)<br>Mail-ID : snapshotsunita@gmail.com</td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
           <tr><td><br/></td><td>6. KAMALIKA BISWAS </td><td><br/></td><td>Role = ( UI  Developer )<br>Mail-ID : kamalika.biswas07@gmail.com</td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
           <tr><td><br/></td><td>7. PURNENDU DAS</td><td><br/></td><td>Role  = (Main Backend Developer  + UI Final Touching)<br>Mail-ID : das888purnendu@gmail.com</td><td><br/></td></tr>
            
            <br/>
            <hr>
          
          
          
          </marquee></div>
   

  </div>



        <div  style="background-color:orange; border:solid 2px orange;border-radius: 10px; width:84%; height:40px; margin-left:10%; margin-top:15px" >
          <marquee behavior="alternate" direction="right" loop="1" style="margin-right:38%" align="center"><h6 style="line-height:1px;">Thank You For Using This System.</h6></marquee>


        </div>


</body>
</html>
